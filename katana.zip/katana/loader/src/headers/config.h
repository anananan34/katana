#pragma once

#define HTTP_SERVER "66.66.66.66"
#define HTTP_PORT 80

#define TFTP_SERVER "66.66.66.66"
